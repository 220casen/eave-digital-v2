const services = [
  ['01', 'Web Design', 'Premium, conversion-focused websites built around one job: turning attention into action.'],
  ['02', 'Development', 'Fast, responsive builds that feel polished on every screen and make contacting your business effortless.'],
  ['03', 'Local Growth', 'Search-ready site structure, analytics and conversion foundations designed to support long-term growth.'],
  ['04', 'Care & Optimization', 'Ongoing improvements, updates and support so your website keeps getting better after launch.'],
];

const work = [
  ['HVAC', 'Climate / Home Services', 'A high-trust service website designed around emergency calls, estimates and local credibility.'],
  ['ROOFING', 'Exterior / Construction', 'A direct-response redesign concept that makes proof, services and quote requests impossible to miss.'],
  ['DETAILING', 'Automotive / Local Service', 'A visual booking experience built to turn before-and-after work into premium appointments.'],
];

export default function Home() {
  return (
    <main>
      <nav className="nav shell">
        <a className="brand" href="#top" aria-label="Eave Digital home"><span>EAVE</span><b>°</b><small>DIGITAL</small></a>
        <div className="navlinks"><a href="#services">Services</a><a href="#work">Work</a><a href="#process">Process</a></div>
        <a className="navcta" href="#contact">Start a project <span>↗</span></a>
      </nav>

      <section className="hero shell" id="top">
        <div className="eyebrow"><span></span> DIGITAL PARTNER FOR SERVICE BUSINESSES</div>
        <h1>BUILT FOR BUSINESS.<br/><em>DESIGNED FOR GROWTH.</em></h1>
        <div className="heroBottom">
          <p>We design high-converting digital experiences for service businesses that want more calls, better leads and a stronger brand.</p>
          <a className="circleLink" href="#contact" aria-label="Start a project">↘</a>
        </div>
      </section>

      <section className="statement dark">
        <div className="shell statementGrid">
          <p className="kicker">THE EAVE APPROACH</p>
          <div><h2>Your website shouldn’t just <i>look good.</i><br/>It should generate business.</h2><p className="muted">We combine strategy, design and conversion thinking to create websites that make established businesses look established — and make the next step obvious for customers.</p></div>
        </div>
      </section>

      <section className="section shell" id="services">
        <div className="sectionHead"><p className="kicker">WHAT WE DO</p><h2>Built to perform.<br/>Not just impress.</h2></div>
        <div className="serviceList">
          {services.map(([n,title,text]) => <article className="service" key={n}><span>{n}</span><h3>{title}</h3><p>{text}</p><b>↗</b></article>)}
        </div>
      </section>

      <section className="work dark" id="work">
        <div className="shell">
          <div className="workHead"><div><p className="kicker">SELECTED WORK</p><h2>Concepts with<br/>a purpose.</h2></div><p>Before our first client case studies, we’re building real-world concept projects around the industries we want to serve. No fake results. Just strong thinking and execution.</p></div>
          <div className="cards">
            {work.map(([name,type,text],i) => <article className={`card c${i+1}`} key={name}><div className="cardTop"><span>CONCEPT 0{i+1}</span><span>↗</span></div><div className="cardVisual"><span>{name}</span></div><div className="cardInfo"><small>{type}</small><h3>{name === 'HVAC' ? 'Comfort that converts.' : name === 'ROOFING' ? 'Trust above the fold.' : 'Premium from first click.'}</h3><p>{text}</p></div></article>)}
          </div>
        </div>
      </section>

      <section className="section shell" id="process">
        <div className="sectionHead"><p className="kicker">HOW IT WORKS</p><h2>Simple process.<br/>Serious execution.</h2></div>
        <div className="steps">
          {[['01','Discover','We learn the business, customers, goals and what the current website is missing.'],['02','Design','We create the direction around trust, clarity and conversion — not decoration.'],['03','Develop','We turn the approved design into a fast, responsive and polished website.'],['04','Launch & Grow','After QA and approval, we launch and build the foundation for ongoing growth.']].map(([n,t,d]) => <div className="step" key={n}><span>{n}</span><h3>{t}</h3><p>{d}</p></div>)}
        </div>
      </section>

      <section className="about">
        <div className="shell aboutGrid"><p className="kicker">WHY EAVE</p><div><h2>Less agency noise.<br/><i>More business thinking.</i></h2><p>Eave Digital is being built around a simple idea: local and service businesses deserve websites that look as credible as the work they do. We focus on clear messaging, premium presentation and a path from visitor to customer.</p><div className="principles"><span>01 / CLARITY</span><span>02 / CRAFT</span><span>03 / CONVERSION</span></div></div></div>
      </section>

      <section className="contact dark" id="contact">
        <div className="shell"><p className="kicker">START A PROJECT</p><h2>READY TO BUILD<br/><i>SOMETHING BETTER?</i></h2><p>Tell us about your business and what you want the website to accomplish.</p><a href="mailto:?subject=Eave%20Digital%20Project%20Inquiry" className="bigButton">START A PROJECT <span>↗</span></a><footer><a className="brand inverse" href="#top"><span>EAVE</span><b>°</b><small>DIGITAL</small></a><p>Built for business. Designed for growth.</p><span>© 2026 EAVE DIGITAL</span></footer></div>
      </section>
    </main>
  );
}
